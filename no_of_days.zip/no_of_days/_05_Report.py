import pandas as pd

class CLASS_REPORT1_Unique_property:
    def __init__(self,unique_df):
        print('')



